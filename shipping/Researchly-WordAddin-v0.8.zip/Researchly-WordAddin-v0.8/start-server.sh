#!/bin/bash
# Start the Researchly server, then open the add-in in Word.
cd "$(dirname "$0")"
PYTHON="${PYTHON:-python3}"
exec "$PYTHON" word-addin/server.py "$@"
