# Researchly Knowledge Base — Sources and Where They Live in the App

*2026-08-10 · Maps every document in `Notes_on_writing/` (plus the original
writing guide) to the principles mined from it and the concrete place each
principle now lives in Researchly: a rule id, a lexicon, an explanation
text, or the roadmap. This is the provenance record — every rule can point
back to the lecture or book that taught it.*

The organizing idea, taken from the NG5001 course: **writing is a dialogue
between writer and (imagined) reader**. The checker plays the reader's
side — a friendly-sceptical reader asking Wallace & Wray's question, "Have
you given me sufficient grounds for accepting your claim?" — and every
suggestion is that reader speaking with a named reason.

---

## 1. Dr Akira Endo — "Scientific writing for infectious disease modelling" (`writing.pdf`)

The single most rule-productive document: field-specific, experience-based,
and almost every tip is checkable. Seven new rules (E-series) plus lexicon
and explanation upgrades:

| Endo's principle | Where it lives now |
|---|---|
| Information density: minimise "empty" sentences ("holistic understanding of complex dynamics") | **E701 empty-phrase** (+ `EMPTY_PHRASES` lexicon) |
| Adversative overuse ("However… However…") | **E702 adversative-run** |
| "This/that/it — what does it refer to?" (ambiguous after long sentences) | **E703 naked-this** (fires only after long preceding sentences, per his own caveat) |
| Facts vs opinions: "is known/considered to be" — who says? cite it | **E704 uncited-consensus** (quiet when a citation is present) |
| "X has not been done — don't take the risk" | **E705 absolute-novelty** (quiet with "to our knowledge") |
| Implicit comparator: "relatively — compared with what?" | **E706 missing-comparator** |
| Results narrative: don't open with "Fig 1 shows…"; lead with the finding | **E707 display-first-opener** (Results only) |
| Bombastic verbs: utilise/employ/leverage/elucidate → use/show | **W201 lexicon extended** (leverage, elucidate added) |
| "in terms of / in light of / in relation to" | **W209** (existing; Endo corroborates) |
| Be humble as a modeller: "children contributed most to flu transmission" NOT OK without "in our model" | **C303's why-text** already carries this; full model-claims check = C307 (review-lens, planned) |
| Therefore/thus require a real logical link | inventory **D-layer** (review lens): logic verification isn't deterministic |
| Different terms = different things; don't fear repetition | **W210/F605 terminology consistency** (v-next priority, now with two independent sources) |
| Leaps of logic; readers have read only what they've read; define at first use | **F601/F602** (acronyms shipped; term-definition = review lens) |
| Figure self-sufficiency, caption "sufficient not necessary", y-axis at 0 | **F611** (review-lens, planned) + future figure checks |
| Intro = Context → Issues → Current status/gap → What you do | **D501/D902** structure model (D902 shipped) |
| Cover letter ≠ abstract; grant = pitch to outsiders; examples beat logic for non-experts | knowledge base only — future "document type: cover letter/grant" modes (matches project brief's context list) |

## 2. NG5001 Unit 1 — "Reading Critically" (`Unit 1 - 2510.pdf`)

The reader's-side framework. Mostly powers explanations and the review
lens, plus one rule:

- **Argument = conclusion + warranting** (Wallace & Wray): the frame behind
  the whole C-series; C303/C302/E704 messages ask the warranting question.
- **The serial-summary literature review** (the KM example: "There are many
  studies dealing with… A claimed… B claimed… By the way…") →
  **L901 serial-summary-opener**, and the review-as-conversation framing in
  its explanation.
- Niche-establishment strategies list (12 ways to establish, 6 ways to
  emphasize) → knowledge for the **D-layer review lens**.
- Critical-reader checklist ("check how authors define key terms and
  whether they are consistent") → corroborates **W210/F605**.

## 3. NG5001 Unit 2 — "Writing Academically" (`Unit 2 - 2510.pdf`)

- **Metadiscourse (Hyland) + coherence**: old-before-new information
  structure (already the known–new contract in the guide); interactive/
  interactional resources give the vocabulary for a future
  **metadiscourse meter** (hedges, boosters, attitude markers, engagement)
  — natural extension of the C301/C305 machinery + M901 metrics.
- **Voice (Wellington et al.)**: "confidence without cockiness, scepticism
  without cynicism" — the calibration philosophy behind C301/C302/C305,
  now quotable in their explanations.
- **Thomas (2016) style checklist** (long sentences, abstract-noun overuse,
  redundancy, vagueness, gratuitous jargon) → independently corroborates
  G103/G106/W206/W202 — added as source attributions in the inventory.
- **Conference abstract structure (Belcher/SciQua + Wallace & Wray focus
  questions)** → **AB801 vague-forward-reference** (shipped) and the
  planned **abstract review lens**: 6-part completeness check (conventional
  wisdom → problematization → question → methods → findings →
  significance) with Pallas's sentence frames as constructive suggestions.
- **Common ground for cross-disciplinary readers** (define jargon, shared
  mental models, examples) → F601 (shipped), F602 (planned), and the
  persona note in the knowledge base.

## 4. Wallace & Wray ch. 4 — "Getting Started on Critical Reading" (`…critical_reading.pdf`)

The five **Critical Synopsis Questions** (Why am I reading this? What are
the authors trying to achieve? What are they claiming? How convincing?
What use can I make of it?) and the **argument-flaw taxonomy** (conclusion
without warranting, warranting without conclusion, illogical conclusion,
unlinked warranting, inadequate warranting).

Where it lives: this is the specification for the **document-level review
lens** — the on-demand "critical reader" pass planned since the synthesis
(research/04's coaching pattern). The flaw taxonomy maps directly onto the
Toulmin audit (C308–C310 in the inventory). The warranting-indicator words
(therefore, because, since, it follows that) join Endo's therefore/thus
observation as the anchor points that pass will inspect. Also the origin of
E704's demand: "demand a convincing warranting for every conclusion."

## 5. Shehzad 2008 — "Move two: establishing a niche" (`03_15_Shehzad (1).pdf` = `Week 2 Reading.pdf`)

The corpus-based anatomy of gap statements:

- **Linguistic indicators of gaps** — contrastives (however, while, but,
  although, nevertheless, as opposed to, with few exceptions), quantifiers/
  quasi-negatives (limited, few, little), negatives (none of, not been, no
  work/research/data/study) → the detection lexicon inside **D902
  missing-niche-signal** (shipped): if an Introduction contains no
  contrastive + gap-word signal, Researchly asks "where is Move 2?"
- Gap-statement types (counter-claiming, gap-indicating, question-raising,
  tradition-continuing) → review-lens taxonomy for D501/D502.
- "Move 2 is the hinge… builds up a demand for the current contribution" →
  D902's explanation text.

## 6. Pallas 2022, *Doctoral Student Skills* (`Doctoral Student Skills….pdf`; ch. 7 duplicated as `Writing conference abstract.pdf`)

- **The 6-part abstract structure + fill-in sentence frames** → AB801's
  rationale + the planned abstract lens; the frames belong in a future
  "abstract scaffold" feature (insert-template with prompts).
- Abstract length pragmatics (match the call; don't come in far under) →
  future doc-level metric ("abstract is 180 words against a 500-word
  limit — reviewers asked for detail").
- Conference-abstract-specific wisdom (new/interesting/focused/informative/
  understandable/enticingly-titled) → knowledge base for the abstract lens.

## 7. Week 2 & Week 4 Key Points (`Week 2/4 Key Points.pdf`)

- Warranting differs by discipline/paradigm (positivist/interpretivist/
  critical; modelling warrants via prediction + validation) → future:
  discipline-conditioned rule packs (the Convention tier's design already
  anticipates this).
- "Use evaluative words, boosters and hedges to strategically foreground
  key claims" + "have a clear gap statement that logically follows" →
  D902 + the planned metadiscourse meter.
- Hyland's interpersonal model diagram; "no writing is neutral" →
  knowledge base framing.

## 8. Understanding Research Paradigm (Omodan 2025)

Context document: paradigms (positivism/interpretivism/critical/pragmatism)
shape what counts as warranting. No deterministic rule — informs the
discipline-conditioned convention packs and reviewer-lens framing. Recorded
so the epistemology behind "different disciplines warrant differently"
has a citable source in the knowledge base.

## 9. Unit 2.2 Task 5 (`Unit 2.2 Task 5.docx`)

The exercise formula — audience → persona → metadiscourse choices — is the
seed for a future "audience profile" setting (who is this document for?)
that would condition tone/register rules, aligning with the project brief's
journal/venue awareness goal.

---

## Shipped this phase (v0.4)

**New rules (10):** E701 empty-phrase · E702 adversative-run · E703
naked-this · E704 uncited-consensus · E705 absolute-novelty · E706
missing-comparator · E707 display-first-opener · AB801
vague-forward-reference (abstracts) · L901 serial-summary-opener · D902
missing-niche-signal (first document-level structural check).

**Lexicon/why upgrades:** W201 + leverage/elucidate; source attributions
throughout. Rule count: 23 → 33. Corpus check on the 8 accepted theses:
total noise 10.1 → 10.2 flags/1000w (+1%) — the new knowledge arrived
without a noise cost, thanks to aggregation and precision guards (E703
fires only after long preceding sentences; E704 is silenced by citations;
E705 by "to our knowledge"; D902 only when an Introduction exists and lacks
any Shehzad-style signal).

## The queue this corpus creates (in rough order of value)

1. **Abstract lens**: Belcher/Pallas 6-part completeness check + sentence
   frames + AB801 + length-vs-call metric — the course's own assignment,
   as a feature.
2. **Metadiscourse meter**: hedges/boosters/attitude markers per section
   (Hyland via Unit 2) — extends the M901 metrics panel.
3. **Critical-reader review lens**: Wallace & Wray's five questions + flaw
   taxonomy + Toulmin audit as the document-level pass (the biggest item;
   pairs with the desktop D1 milestone).
4. **Terminology consistency (W210/F605)** — now demanded by three
   independent sources (guide §6, Endo, Wallace & Wray checklist).
5. **Audience/persona setting** conditioning register rules (Unit 2.2).
